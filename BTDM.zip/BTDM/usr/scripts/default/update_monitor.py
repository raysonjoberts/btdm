
import os
import time
import subprocess
from datetime import datetime

# Determine base path (/Root)
BTDM_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.abspath(os.path.join(SCRIPT_DIR, "..", ".."))

# Paths
UPDATE_FLAG = os.path.join(BTDM_ROOT, "var", "logs", ".last_update_check")
UPDATER = os.path.join(BTDM_ROOT, "usr", "scripts", "default", "updater.py")
LOG_FILE = os.path.join(BTDM_ROOT, "var", "logs", "update.log")

def write_log(message):
    timestamp = datetime.now().strftime("%m/%d/%Y %H:%M:%S")
    with open(LOG_FILE, "a") as f:
        f.write(f"{timestamp},update_monitor.py,check_updates,{message}\n")

def needs_update():
    if not os.path.exists(UPDATE_FLAG):
        return True
    last_check = os.path.getmtime(UPDATE_FLAG)
    return (time.time() - last_check) >= 86400

def check_for_updates():
    while True:
        if needs_update():
            try:
                with open(UPDATE_FLAG, "w") as f:
                    f.write(datetime.now().isoformat())
                subprocess.run(["/usr/bin/env", "python3", UPDATER])
                write_log("Ran update via updater.py")
            except Exception as e:
                write_log(f"Update failed: {e}")
        time.sleep(3600)

if __name__ == "__main__":
    check_for_updates()
