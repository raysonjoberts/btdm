
import os
import zipfile
import requests
from datetime import datetime

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
BTDM_ROOT = os.path.abspath(os.path.join(SCRIPT_DIR, "..", ".."))
CONFIG_PATH = os.path.join(BTDM_ROOT, "usr", "config", "default", "update_source.json")
LOG_FILE = os.path.join(BTDM_ROOT, "var", "logs", "update.log")

def write_log(message):
    timestamp = datetime.now().strftime("%m/%d/%Y %H:%M:%S")
    with open(LOG_FILE, "a") as f:
        f.write(f"{timestamp},updater.py,update,{message}\n")

def get_update_info():
    import json
    with open(CONFIG_PATH, "r") as f:
        return json.load(f)

def apply_update(zip_path):
    with zipfile.ZipFile(zip_path, 'r') as z:
        for member in z.namelist():
            if "/default/" in member:
                target_path = os.path.join(BTDM_ROOT, *member.split("/")[1:])
                os.makedirs(os.path.dirname(target_path), exist_ok=True)
                with open(target_path, 'wb') as out_file:
                    out_file.write(z.read(member))
                write_log(f"Updated: {target_path}")

def check_for_updates():
    try:
        info = get_update_info()
        url = info["url"]
        zip_temp = os.path.join(BTDM_ROOT, "ext", "btdm_update.zip")

        write_log(f"Checking for update from: {url}")
        response = requests.get(url)
        with open(zip_temp, "wb") as f:
            f.write(response.content)

        apply_update(zip_temp)
        write_log("Update applied successfully.")

    except Exception as e:
        write_log(f"Update failed: {e}")

if __name__ == "__main__":
    check_for_updates()
