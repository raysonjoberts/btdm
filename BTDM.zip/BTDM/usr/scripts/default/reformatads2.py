
import os
import pandas as pd

# === Configuration ===
ADS2_INPUT_PATH = os.path.join("..", "customerdata", "somt4_ads2_apptostaff_2025-05-16.xlsx")
OUTPUT_CSV_PATH = os.path.join("..", "tables", "formatted_ads2_output.csv")

def reformat_ads2_to_application_table(df_ads2: pd.DataFrame) -> pd.DataFrame:
    # Clean whitespace
    df_ads2["Staff Role"] = df_ads2["Staff Role"].str.strip()
    df_ads2["Application"] = df_ads2["Application"].astype(str).str.strip()

    # Pivot the table by application
    pivot_df = df_ads2.pivot_table(
        index="Application",
        columns="Staff Role",
        values="Staff Name",
        aggfunc="first"
    ).reset_index()

    # Metadata: App Id, Dept, Title, Title Name
    metadata = df_ads2.groupby("Application")[["App Id", "Dept", "Title", "Title Name"]].first().reset_index()

    # Merge pivoted staff roles with metadata
    formatted_df = pd.merge(metadata, pivot_df, on="Application", how="left")

    # Optional: define a desired column order
    role_fields = sorted(pivot_df.columns.drop("Application").tolist())  # Sorted for consistency
    column_order = ["App Id", "Application"] + role_fields + ["Dept", "Title", "Title Name"]

    # Ensure all fields exist
    for col in column_order:
        if col not in formatted_df.columns:
            formatted_df[col] = None

    # Reorder and return
    return formatted_df[column_order]

if __name__ == "__main__":
    # Ensure output directory exists
    os.makedirs(os.path.dirname(OUTPUT_CSV_PATH), exist_ok=True)

    # Load ads2 input
    df_ads2 = pd.read_excel(ADS2_INPUT_PATH)

    # Reformat and export
    formatted = reformat_ads2_to_application_table(df_ads2)
    formatted.to_csv(OUTPUT_CSV_PATH, index=False)
    print(f"Formatted ads2 data saved to: {OUTPUT_CSV_PATH}")
