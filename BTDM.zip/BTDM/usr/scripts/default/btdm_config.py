import os
import pandas as pd

# Detect the absolute root of the BTDM system
BTDM_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))

# Load config from default directory
CONFIG_PATH = os.path.join(BTDM_ROOT, "config", "default", "customer_sources.csv")

# Load CSV config
df_config = pd.read_csv(CONFIG_PATH)

# List of full paths to monitor
MONITORED_SOURCES = df_config["Customer Source Location"].tolist()

# Folder name to prefix mapping (last part of path → variable name)
FOLDER_PREFIX_MAP = {
    os.path.basename(path.strip()): row["Variable Name"].strip()
    for _, row in df_config.iterrows()
    for path in [row["Customer Source Location"]]
}