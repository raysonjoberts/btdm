
import pandas as pd

def reformat_ads1(df: pd.DataFrame, source_field: str) -> pd.DataFrame:
    if source_field not in df.columns:
        raise ValueError(f"Source field '{source_field}' not found in the input data.")

    # Copy source field to unified Application field
    df["Application"] = df[source_field]

    # Create 'Server' field if 'Server Name' exists
    if "Server Name" in df.columns:
        df["Server"] = df["Server Name"].astype(str).str.lower()

    return df
