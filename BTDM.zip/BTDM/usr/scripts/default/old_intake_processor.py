
import os
import time
import pandas as pd
from datetime import datetime
from reformatads2 import reformat_ads2_to_application_table
from reformat_sds import reformat_sds
from reformat_ads1 import reformat_ads1
from reformat_rvtools import reformat_rvtools_vinfo, reformat_rvtools_vpartition

# === CONFIGURATION ===
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
#CUSTOMERDATA_DIR = os.path.join(SCRIPT_DIR, "..", "customerdata")
CUSTOMERDATA_DIR = os.path.abspath(os.path.join(SCRIPT_DIR, "..", "..", "var", "customerdata"))
#OUTPUT_DIR = os.path.join(SCRIPT_DIR, "..", "tables")
#OUTPUT_DIR = os.path.abspath(os.path.join(SCRIPT_DIR, "..", "tables"))
OUTPUT_DIR = os.path.abspath(os.path.join(SCRIPT_DIR, "..", "..", "var", "tables"))
LOG_DIR = os.path.abspath(os.path.join(SCRIPT_DIR, "..", "..", "var", "logs"))
os.makedirs(LOG_DIR, exist_ok=True)
LOG_FILE = os.path.join(LOG_DIR, f"btdm_{datetime.now().strftime('%Y%m%d')}.log")

# === INITIALIZATION ===
os.makedirs(OUTPUT_DIR, exist_ok=True)
seen_files = set()

def write_log(function, message):
    timestamp = datetime.now().strftime("%m/%d/%Y %H:%M:%S")
    with open(LOG_FILE, "a") as log:
        log.write(f"{timestamp},intake_processor.py,{function},{message}\n")

def get_new_files():
    return sorted([
        f for f in os.listdir(CUSTOMERDATA_DIR)
        if f.endswith(".xlsx") and not f.startswith("~$")
    ], key=lambda f: os.path.getmtime(os.path.join(CUSTOMERDATA_DIR, f)), reverse=True)

def strip_date_suffix(filename):
    base = os.path.splitext(filename)[0]
    parts = base.split("_")
    if len(parts) >= 2 and parts[-1].isdigit():
        return "_".join(parts[:-1])
    return base

def process_file(filepath, filename):
    write_log("process_file", f"Processing new file: {filepath}")
    try:
        if "ads1" in filename.lower():
            df = pd.read_excel(filepath)
            possible_fields = [col for col in df.columns if col.strip().lower().startswith("application")]
            if not possible_fields:
                raise ValueError("No application-like field found in ads1 input.")
            source_field = possible_fields[0]
            reformatted = reformat_ads1(df, source_field=source_field)
            output_name = f"{strip_date_suffix(filename)}_ads1.csv"
            reformatted.to_csv(os.path.join(OUTPUT_DIR, output_name), index=False)
            write_log("process_file", f"ads1 reformatted and saved to {output_name}")

        elif "ads2" in filename.lower():
            df = pd.read_excel(filepath)
            reformatted = reformat_ads2_to_application_table(df)
            output_name = f"{strip_date_suffix(filename)}_ads2.csv"
            reformatted.to_csv(os.path.join(OUTPUT_DIR, output_name), index=False)
            write_log("process_file", f"ads2 reformatted and saved to {output_name}")

        elif "sds1" in filename.lower():
            df = pd.read_excel(filepath)
            reformatted = reformat_sds(df, source_field="SERVERNAME")
            output_name = f"{strip_date_suffix(filename)}_ads1.csv"
            reformatted.to_csv(os.path.join(OUTPUT_DIR, output_name), index=False)
            write_log("process_file", f"sds1 reformatted and saved to {output_name}")

        elif "sds2" in filename.lower() or "rvtools" in filename.lower():
            xls = pd.ExcelFile(filepath)
            sheet_map = {s.lower(): s for s in xls.sheet_names}
            prefix = strip_date_suffix(filename)

            if "vinfo" in sheet_map:
                df_vinfo = xls.parse(sheet_map["vinfo"])
                df_vinfo = reformat_rvtools_vinfo(df_vinfo)
                out_vinfo = f"{prefix}_vinfo_ads2.csv"
                df_vinfo.to_csv(os.path.join(OUTPUT_DIR, out_vinfo), index=False)
                write_log("process_file", f"sds2 vinfo reformatted and saved to {out_vinfo}")

            if "vpartition" in sheet_map:
                df_vpart = xls.parse(sheet_map["vpartition"])
                df_vpart = reformat_rvtools_vpartition(df_vpart)
                out_vpart = f"{prefix}_vpartition_ads2.csv"
                df_vpart.to_csv(os.path.join(OUTPUT_DIR, out_vpart), index=False)
                write_log("process_file", f"sds2 vpartition reformatted and saved to {out_vpart}")

    except Exception as e:
        write_log("process_file", f"Error processing {filename}: {e}")

def monitor_customerdata():
    write_log("monitor_customerdata", f"Monitoring {CUSTOMERDATA_DIR} for new supported files...")
    while True:
        files = get_new_files()
        for latest_file in files:
            if latest_file not in seen_files:
                seen_files.add(latest_file)
                full_path = os.path.join(CUSTOMERDATA_DIR, latest_file)
                process_file(full_path, latest_file)
        time.sleep(10)

if __name__ == "__main__":
    monitor_customerdata()
