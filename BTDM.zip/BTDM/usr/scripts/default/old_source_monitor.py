
import os
import time
import shutil
from datetime import datetime
from btdm_config import MONITORED_SOURCES, FOLDER_PREFIX_MAP

# === CONFIGURATION ===
SCRIPT_NAME = "source_monitor.py"
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CUSTOMERDATA_DIR = os.path.abspath(os.path.join(SCRIPT_DIR, "..", "..", "var","customerdata"))
LOG_DIR = os.path.abspath(os.path.join(SCRIPT_DIR, "..", "..", "var", "logs"))
os.makedirs(LOG_DIR, exist_ok=True)
os.makedirs(CUSTOMERDATA_DIR, exist_ok=True)
LOG_FILE = os.path.join(LOG_DIR, f"btdm_{datetime.now().strftime('%Y%m%d')}.log")

seen_files = {}

def write_log(function, message):
    timestamp = datetime.now().strftime("%m/%d/%Y %H:%M:%S")
    with open(LOG_FILE, "a") as log:
        log.write(f"{timestamp},{SCRIPT_NAME},{function},{message}\n")

def detect_folder_prefix(source_path):
    for folder in FOLDER_PREFIX_MAP:
        if folder in source_path:
            return FOLDER_PREFIX_MAP[folder]
    return "data"

def copy_and_standardize_file(file_path, prefix):
    today = datetime.now().strftime("%Y%m%d")
    new_filename = f"{prefix}_{today}.xlsx"
    dest_path = os.path.join(CUSTOMERDATA_DIR, new_filename)
    shutil.copy2(file_path, dest_path)
    write_log("copy_and_standardize_file", f"Copied {file_path} to {dest_path}")

def monitor_sources():
    write_log("monitor_sources", "Monitoring multiple source folders...")
    while True:
        for folder in MONITORED_SOURCES:
            if not os.path.exists(folder):
                continue
            for file in os.listdir(folder):
                if not file.endswith((".xlsx", ".xls")) or file.startswith("~$"):
                    continue
                full_path = os.path.join(folder, file)
                last_modified = os.path.getmtime(full_path)
                key = os.path.abspath(full_path)

                if key not in seen_files or seen_files[key] < last_modified:
                    prefix = detect_folder_prefix(folder)
                    copy_and_standardize_file(full_path, prefix)
                    seen_files[key] = last_modified
        time.sleep(10)

if __name__ == "__main__":
    monitor_sources()
