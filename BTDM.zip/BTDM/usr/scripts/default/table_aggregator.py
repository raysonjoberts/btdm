
import os
import time
import pandas as pd
from functools import reduce
from datetime import datetime

# === CONFIGURATION ===
BTDM_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
SCRIPT_NAME = "table_aggregator.py"
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
TABLES_DIR = os.path.join(BTDM_ROOT, "var", "tables")
LOG_DIR = os.path.join(BTDM_ROOT, "var", "logs")
os.makedirs(LOG_DIR, exist_ok=True)
LOG_FILE = os.path.join(LOG_DIR, f"btdm_{datetime.now().strftime('%Y%m%d')}.log")

MASTER_SDS_FILENAME = "master_server_inventory.csv"
MASTER_ADS_FILENAME = "master_application_inventory.csv"

ads_timestamps = {}
sds_timestamps = {}

def write_log(function, message):
    timestamp = datetime.now().strftime("%m/%d/%Y %H:%M:%S")
    with open(LOG_FILE, "a") as log:
        log.write(f"{timestamp},{SCRIPT_NAME},{function},{message}\n")

def get_csv_files():
    return sorted([
        f for f in os.listdir(TABLES_DIR)
        if f.endswith(".csv") and not f.startswith("~$") and not f.startswith("master_")
    ])

def read_and_merge(files, key_field):
    dfs = []
    for file in files:
        path = os.path.join(TABLES_DIR, file)
        try:
            df = pd.read_csv(path)
            if key_field in df.columns:
                df = df.drop_duplicates(subset=[key_field])
                dfs.append(df.set_index(key_field))
                write_log("read_and_merge", f"Including {file}")
        except Exception as e:
            write_log("read_and_merge", f"Error reading {file}: {e}")
    if not dfs:
        return pd.DataFrame()
    merged = reduce(lambda left, right: pd.merge(left, right, left_index=True, right_index=True, how="outer"), dfs)
    merged.reset_index(inplace=True)
    return merged

def compile_master_sds():
    write_log("compile_master_sds", "Rebuilding master SDS table")
    sds_files = [f for f in get_csv_files() if "sds" in f.lower()]
    merged = read_and_merge(sds_files, key_field="Server")
    merged.to_csv(os.path.join(TABLES_DIR, MASTER_SDS_FILENAME), index=False)
    write_log("compile_master_sds", f"{MASTER_SDS_FILENAME} updated.")

def compile_master_ads():
    write_log("compile_master_ads", "Rebuilding master ADS table")
    ads_files = [f for f in get_csv_files() if "ads" in f.lower()]
    merged = read_and_merge(ads_files, key_field="Application")
    merged.to_csv(os.path.join(TABLES_DIR, MASTER_ADS_FILENAME), index=False)
    write_log("compile_master_ads", f"{MASTER_ADS_FILENAME} updated.")

def monitor_tables():
    write_log("monitor_tables", f"Monitoring {TABLES_DIR} for changes...")
    while True:
        files = get_csv_files()
        sds_changed = False
        ads_changed = False

        for f in files:
            path = os.path.join(TABLES_DIR, f)
            mtime = os.path.getmtime(path)

            if "sds" in f.lower():
                if f not in sds_timestamps or sds_timestamps[f] != mtime:
                    sds_timestamps[f] = mtime
                    sds_changed = True

            elif "ads" in f.lower():
                if f not in ads_timestamps or ads_timestamps[f] != mtime:
                    ads_timestamps[f] = mtime
                    ads_changed = True

        if sds_changed:
            compile_master_sds()
        if ads_changed:
            compile_master_ads()

        time.sleep(10)

if __name__ == "__main__":
    monitor_tables()
