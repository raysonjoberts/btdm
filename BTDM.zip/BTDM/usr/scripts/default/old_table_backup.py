
import os
import time
import shutil
from datetime import datetime

# === CONFIGURATION ===
SCRIPT_NAME = "backup_master_tables.py"
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
#TABLES_DIR = os.path.join(SCRIPT_DIR, "..", "tables")
TABLES_DIR = os.path.abspath(os.path.join(SCRIPT_DIR, "..", "..", "var", "tables"))
ARCHIVE_DIR = "/Users/jaysonroberts/Google Drive/Indexing/SOMT6/tables"  # <- update this with real path
LOG_DIR = os.path.abspath(os.path.join(SCRIPT_DIR, "..", "..", "var", "logs"))
os.makedirs(LOG_DIR, exist_ok=True)
os.makedirs(ARCHIVE_DIR, exist_ok=True)
LOG_FILE = os.path.join(LOG_DIR, f"btdm_{datetime.now().strftime('%Y%m%d')}.log")

def write_log(function, message):
    timestamp = datetime.now().strftime("%m/%d/%Y %H:%M:%S")
    with open(LOG_FILE, "a") as log:
        log.write(f"{timestamp},{SCRIPT_NAME},{function},{message}\n")

def wait_until_5am():
    while True:
        now = datetime.now()
        if now.hour == 5:
            return
        write_log("wait_until_5am", f"Sleeping... Current time: {now.strftime('%H:%M:%S')}")
        time.sleep(300)  # check every 5 minutes

def backup_master_tables():
    while True:
        wait_until_5am()
        try:
            for file in os.listdir(TABLES_DIR):
                if file.startswith("master_") and file.endswith(".csv"):
                    src_path = os.path.join(TABLES_DIR, file)
                    dst_path = os.path.join(ARCHIVE_DIR, f"{file.replace('.csv', '')}_{datetime.now().strftime('%Y%m%d')}.csv")
                    shutil.copy2(src_path, dst_path)
                    write_log("backup_master_tables", f"Backed up {file} to {dst_path}")
        except Exception as e:
            write_log("backup_master_tables", f"Error: {e}")
        time.sleep(86400)  # sleep 1 day after backup

if __name__ == "__main__":
    backup_master_tables()
