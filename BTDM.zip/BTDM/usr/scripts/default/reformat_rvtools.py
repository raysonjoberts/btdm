
import pandas as pd
import re

def clean_server_name(value):
    if pd.isna(value):
        return None
    value = str(value).lower()
    value = re.sub(r"\..*$", "", value)  # remove FQDN
    value = re.sub(r"[^a-zA-Z0-9-_]", "", value)  # remove unwanted characters
    return value

def reformat_rvtools_vinfo(df: pd.DataFrame) -> pd.DataFrame:
    if "VM" not in df.columns:
        raise ValueError("Expected column 'VM' not found in vInfo sheet.")
    df["Server"] = df["VM"].apply(clean_server_name)
    return df

def reformat_rvtools_vpartition(df: pd.DataFrame) -> pd.DataFrame:
    required_columns = ["VM", "Capacity MiB", "Consumed MiB"]
    for col in required_columns:
        if col not in df.columns:
            raise ValueError(f"Expected column '{col}' not found in vPartition sheet.")

    df["Server"] = df["VM"].apply(clean_server_name)

    # Remove commas and convert to numeric
    df["Capacity MiB"] = df["Capacity MiB"].astype(str).str.replace(",", "").astype(float)
    df["Consumed MiB"] = df["Consumed MiB"].astype(str).str.replace(",", "").astype(float)

    # Aggregate totals by Server
    agg = df.groupby("Server", as_index=False).agg({
        "Capacity MiB": "sum",
        "Consumed MiB": "sum"
    })
    agg["Percent Partition Utilization"] = round((agg["Consumed MiB"] / agg["Capacity MiB"]) * 100).astype(str) + "%"
    agg["Total Capacity GB"] = round(agg["Capacity MiB"] / 953.674, 2)
    agg["Total Consumed GB"] = round(agg["Consumed MiB"] / 953.674, 2)
    agg["Percent Consumed"] = round((agg["Total Consumed GB"] / agg["Total Capacity GB"]) * 100, 2).astype(str) + "%"

    return agg
